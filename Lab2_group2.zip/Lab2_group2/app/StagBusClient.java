package app;
 
import linkedList.LinkedList;
import linkedList.LinkedListImpl;
import queue.Queue;
import queue.QueueImpl;
import stack.Stack;
import stack.StackImpl;

public class StagBusClient {

	public static void main(String[] args) {
		// create implementation, then

		System.out.println("-----L I S T  T E S T------");
		LLrun();
		//listRunTestMethod...
 		
		System.out.println("-----S T A C K  T E S T------");
		Srun();
		//QRunTestMethod...
	 
		System.out.println("----Q U E U E  T E S T-------");
		Qrun();
		//StackRunTestMethod...
		
	 	}
	
	public static void LLrun() {
			// create implementation, then...
			LinkedList route = new LinkedListImpl();		//initializes the LinkedList
			route.addItem("Grocery Store");					//adds item
			route.addItem("Chick-fil-a");					//adds item
			route.addItem("Beach");							//adds item
			route.addItem("Campus");						//adds item
			route.listItems();								//displays list
			System.out.println();
			route.isItemInList("Beach");					//checks if item is in list (true)
			System.out.println();
			route.isItemInList("Canada");					//checks if item is in list (false)
			System.out.println();
			route.deleteItem("Chick-fil-a");				//deletes item
			route.listItems();								//displays list
			System.out.println();
			route.insertBefore("Starbucks", "Beach");		//inserts item before "Beach"
			route.listItems();								//displays list
			System.out.println();
			route.insertAfter("Target", "Campus");			//inserts item 
			route.listItems();								//displays list
		
	}
	
	public static void Srun() {

		Stack stack = new StackImpl(8);					//initializes the Stack
		stack.push("John Doe");							//add rider
		stack.push("Bob McDonald");						//add rider
		stack.push("Billy Kennedy");					//add rider
		stack.push("Jane Foe");							//add rider
		stack.push("Zach Don");							//add rider
		stack.push("Mia Thompson");						//add rider
		stack.display();								//print stack
		System.out.println();
		stack.peek();									//peek at stack
		System.out.println();
		stack.pop();									//pop top item
		stack.display();								//print stack
		System.out.println();
		stack.peek();									//peek at stack
		System.out.println();
		stack.push("Jeremy West");						//add rider
		stack.push("Frank kay");						//add rider
		stack.peek();									//peek at stack
		System.out.println();
		while (stack.isEmpty() == false) {				//while stack is not empty
			stack.pop();								//pop top item
		}
		System.out.println(stack.isEmpty());			//prints if stack is empty
	}
	
	public static void Qrun() {
		Queue queue = new QueueImpl();					//initializes the Queue
		queue.enQueue("John Doe");						//add rider
		queue.enQueue("Bob McDonald");					//add rider
		queue.enQueue("Billy Kennedy");					//add rider
		queue.enQueue("Jane Foe");						//add rider
		queue.enQueue("Zach Don");						//add rider
		queue.enQueue("Mia Thompson");					//add rider
		queue.display();								//print queue
		System.out.println();
		queue.peek();									//peek at queue
		System.out.println();
		queue.deQueue();								//dequeue top item
		queue.display();								//print queue
		System.out.println();
		queue.enQueue("Jeremy West");					//add rider
		queue.enQueue("Frank kay");						//add rider
		queue.peek();									//peek at queue
		System.out.println();
		queue.deQueue();								//dequeue top item
		queue.display();								//print queue
		System.out.println();	
	}

}
