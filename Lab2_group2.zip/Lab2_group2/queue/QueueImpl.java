package queue;

public class QueueImpl implements Queue {
	
	protected final int DEFCAP = 100; // default capacity
	protected String[] elements ;     // array that holds queue elements
	protected int numElements = 0;    // number of elements in this queue
	protected int front = 0;          // index of front of queue
	protected int rear;               // index of rear of queue
	
	public QueueImpl() 
	  {
	    elements = (String[]) new String[DEFCAP];
	    rear = DEFCAP - 1;
	  }

	@Override
	public boolean isFull() {
		return (numElements == elements.length);
	}

	@Override
	public boolean isEmpty() {
	    return (numElements == 0);
	}

	@Override
	public void enQueue(String element) {
		if (isFull()) {
		     System.out.println("Enqueue attempted on a full queue.");
		}else{
		     rear = (rear + 1) % elements.length;
		     elements[rear] = element;
		     numElements = numElements + 1;
		    }
	}

	@Override
	public String deQueue() {
		if (isEmpty()) {
			System.out.println("Dequeue attempted on empty queue.");
			return null;
		}else{
		    String toReturn = elements[front];
		    elements[front] = null;
		    front = (front + 1) % elements.length;
		    numElements = numElements - 1;
		    return toReturn;
	    }
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		for (int i = rear; i >= front ; i--) {
			System.out.println(elements[i]);
		}
	}

	@Override
	public String peek() {
		// TODO Auto-generated method stub
		System.out.println(elements[front]);
		return null;
	}

}
