package queue;


public class QueueTester {

	public static void main(String[] args) {
		Queue queue = new QueueImpl();					//initializes the Queue
		queue.enQueue("John Doe");						//add rider
		queue.enQueue("Bob McDonald");					//add rider
		queue.enQueue("Billy Kennedy");					//add rider
		queue.enQueue("Jane Foe");						//add rider
		queue.enQueue("Zach Don");						//add rider
		queue.enQueue("Mia Thompson");					//add rider
		queue.display();								//print queue
		System.out.println();
		queue.peek();									//peek at queue
		System.out.println();
		queue.deQueue();								//dequeue top item
		queue.display();								//print queue
		System.out.println();
		queue.enQueue("Jeremy West");					//add rider
		queue.enQueue("Frank kay");						//add rider
		queue.peek();									//peek at queue
		System.out.println();
		queue.deQueue();								//dequeue top item
		queue.display();								//print queue
		System.out.println();	
	}

}
